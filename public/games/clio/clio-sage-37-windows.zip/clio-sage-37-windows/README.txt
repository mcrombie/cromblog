﻿CLIO: THE LIVING ATLAS â€” sage-37
Experimental Windows desktop prototype. Updated September 13, 2026.

PLAY
Extract the entire ZIP to a folder, then open Clio.exe. Keep
Clio.Simulation.dll beside it. Windows 10 or 11 with .NET Framework 4.x
is the intended environment. No compiler, account or connection is needed.

New stories use Guided beginning: meet the First Adviser, end the first
turn, then spend influence on Gather or regional Move. Wildlife can be
inspected from turn 2. Move previews destinations on the map. The adviser
reports supply changes and animal sightings. V mutes or unmutes narration.
F11 returns the full-screen game to a window.

Uncheck Guided beginning in New story for the older game modes.
Save before updating and retain a copy of your original story. This build
writes CLIO-STORY-16 and records the guided-wildlife upgrade; earlier
versions cannot read all new saves.

VOICE
The two synthetic British opening recordings are included. Live reports
use an installed Windows voice. For the same optional British voice in
live reports, close Clio and run Enable offline adviser voice.cmd. That
explicit setup downloads approximately 97 MB from the pinned upstream
Piper and voice-model releases, verifies their SHA-256 checksums and
installs them beside the game. Reopen Clio afterward. The game performs
no automatic downloads and sends no narration text to a service.

See voice-credits.md and tools/voice-licenses for credits and notices.

STATUS
Compilation and archive integrity verified. Gameplay and audio have not
been verified for this release. The prototype is still in development.

Source: https://github.com/mcrombie/clio
Source revision: local e9dab30aff51bbb33bb117c93017e854b6f91d36
Project: https://cromblog.vercel.app/games#clio
