@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\enable-offline-voice.ps1"
if errorlevel 1 (
  echo Voice setup did not finish. Clio can still use installed Windows speech.
)
pause
